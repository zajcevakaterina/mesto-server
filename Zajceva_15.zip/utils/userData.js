const defaultName = 'Ваше имя';
const defaultAbout = 'Информация о вас';
const defaultAvatar = 'https://cdn.pixabay.com/photo/2017/11/10/05/48/user-2935527_1280.png';

module.exports = {
  defaultName,
  defaultAbout,
  defaultAvatar,
};
